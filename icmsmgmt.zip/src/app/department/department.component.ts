import { Component, OnInit } from '@angular/core';
import { Department } from "./department"; 
@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  constructor() { }
  public products: Department[] = [
    new Department(1, "Tamil","Tamil Department"),
    new Department(2, "English","English Department"),
    new Department(3, "Maths","Maths Department"),
    new Department(4, "Science","Science Department"),
    new Department(5, "Electronics and Electrical","Electrical and Electronics")
    
  ];
  title= 'Department List';
  dtOptions ={};

  ngOnInit() {
    this.dtOptions={
      pagingType: 'full_numbers',
      pageLength :5,
      processing:true
    }
  }

}
