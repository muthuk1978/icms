import { RouterModule, Routes } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";
import { DepartmentComponent } from './department/department.component';


const routes: Routes = [
  { path: "department", component: DepartmentComponent },
];

export const routingModule: ModuleWithProviders = RouterModule.forRoot(routes);
